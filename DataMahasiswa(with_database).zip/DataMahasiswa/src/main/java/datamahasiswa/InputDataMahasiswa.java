package datamahasiswa;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class InputDataMahasiswa extends javax.swing.JPanel {

    Connection con;
    DefaultTableModel model;

    /**
     * Constructor Utama (Nama harus SAMA dengan nama Class)
     */
    public InputDataMahasiswa() {
        initComponents();
        // Memanggil fungsi tampil data saat aplikasi pertama kali dibuka
        load_data();
    }
    
    private void load_data() {
        String[] judul = {"NIM", "Nama", "Jenis Kelamin", "Jurusan"};
        model = new DefaultTableModel(judul, 0);
        tableMahasiswa.setModel(model);
        
        try {
            // SIlakan ganti "db_mahasiswa" sesuai dengan nama database kamu di phpMyAdmin
            con = DriverManager.getConnection("jdbc:mysql://localhost/kampus_db", "root", "");
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM mahasiswa");
            
            while(rs.next()) {
                String[] data = {
                    rs.getString("nim"),         // Sesuaikan nama kolom di database kamu
                    rs.getString("nama"), 
                    rs.getString("jenis_kelamin"), 
                    rs.getString("jurusan")
                };
                model.addRow(data);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal memuat data: " + e.getMessage());
        }
    }
    
    private void clear_form() {
        txtNIM.setText("");
        txtNama.setText("");
        buttonGroup1.clearSelection(); // Mematikan pilihan radio button
        cbJurusan.setSelectedIndex(0);  // Mengembalikan combobox ke pilihan pertama
        txtNIM.setEditable(true);       // Membuka kembali kunci input NIM
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtNIM = new javax.swing.JTextField();
        txtNama = new javax.swing.JTextField();
        btnSimpan = new javax.swing.JButton();
        btnUbah = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableMahasiswa = new javax.swing.JTable();
        Jurusan = new javax.swing.JLabel();
        rbLaki = new javax.swing.JRadioButton();
        rbPerempuan = new javax.swing.JRadioButton();
        btnHapus = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        cbJurusan = new javax.swing.JComboBox<>();

        jLabel1.setText("Master Mahasiswa");

        jLabel2.setText("NIM");

        jLabel3.setText("Nama");

        jLabel4.setText("Jenis Kelamin");

        txtNIM.addActionListener(this::txtNIMActionPerformed);

        txtNama.addActionListener(this::txtNamaActionPerformed);

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(this::btnSimpanActionPerformed);

        btnUbah.setText("Ubah");
        btnUbah.addActionListener(this::btnUbahActionPerformed);

        tableMahasiswa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        tableMahasiswa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "NIM", "Nama", "Jenis Kelamin", "Jurusan"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        tableMahasiswa.setGridColor(new java.awt.Color(0, 0, 0));
        tableMahasiswa.setShowGrid(true);
        tableMahasiswa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMahasiswaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableMahasiswa);

        Jurusan.setText("Jurusan");

        buttonGroup1.add(rbLaki);
        rbLaki.setText("Laki-Laki");
        rbLaki.addActionListener(this::rbLakiActionPerformed);

        buttonGroup1.add(rbPerempuan);
        rbPerempuan.setText("Perempuan");
        rbPerempuan.addActionListener(this::rbPerempuanActionPerformed);

        btnHapus.setText("Hapus");
        btnHapus.addActionListener(this::btnHapusActionPerformed);

        btnKeluar.setText("Keluar");
        btnKeluar.addActionListener(this::btnKeluarActionPerformed);

        cbJurusan.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Tenknik Mesin", "Teknik Elektronika", "Teknologi Industri", "Teknologi Informasi" }));
        cbJurusan.addActionListener(this::cbJurusanActionPerformed);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(103, 103, 103)
                        .addComponent(btnSimpan)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnUbah)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnHapus)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnKeluar))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3)
                            .addComponent(jLabel2)
                            .addComponent(Jurusan))
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(25, 25, 25)
                                .addComponent(rbLaki)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
                                .addComponent(rbPerempuan)
                                .addGap(34, 34, 34))
                            .addComponent(txtNIM)
                            .addComponent(txtNama)
                            .addComponent(cbJurusan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(209, 209, 209)
                        .addComponent(jLabel1)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(36, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(33, 33, 33)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNIM, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNama, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rbLaki)
                    .addComponent(rbPerempuan)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cbJurusan, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Jurusan, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnSimpan)
                    .addComponent(btnUbah)
                    .addComponent(btnHapus)
                    .addComponent(btnKeluar))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
        String nim = txtNIM.getText();
        String nama = txtNama.getText();
        String jurusan = cbJurusan.getSelectedItem().toString();
        
        String jk = "";
        if (rbLaki.isSelected()) {
            jk = "Laki-Laki";
        } else if (rbPerempuan.isSelected()) {
            jk = "Perempuan";
        }
        
        // Validasi input kosong
        if (nim.isEmpty() || nama.isEmpty() || jk.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Semua data wajib diisi!");
            return;
        }
        
        try {
            String sql = "INSERT INTO mahasiswa VALUES ('" + nim + "', '" + nama + "', '" + jk + "', '" + jurusan + "')";
            Statement st = con.createStatement();
            st.executeUpdate(sql);
            
            JOptionPane.showMessageDialog(this, "Data Berhasil Disimpan!");
            load_data();
            clear_form();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal Simpan: " + e.getMessage());
        }
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void txtNIMActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNIMActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNIMActionPerformed

    private void txtNamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtNamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtNamaActionPerformed

    private void btnUbahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUbahActionPerformed
        String nim = txtNIM.getText();
        String nama = txtNama.getText();
        String jurusan = cbJurusan.getSelectedItem().toString();
        String jk = rbLaki.isSelected() ? "Laki-Laki" : "Perempuan";
        
        try {
            String sql = "UPDATE mahasiswa SET nama='" + nama + "', jenis_kelamin='" + jk + "', jurusan='" + jurusan + "' WHERE nim='" + nim + "'";
            Statement st = con.createStatement();
            st.executeUpdate(sql);
            
            JOptionPane.showMessageDialog(this, "Data Berhasil Diubah!");
            load_data();
            clear_form();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Gagal Mengubah Data: " + e.getMessage());
        }
    }//GEN-LAST:event_btnUbahActionPerformed

    private void rbLakiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbLakiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbLakiActionPerformed

    private void rbPerempuanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rbPerempuanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rbPerempuanActionPerformed

    private void btnHapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHapusActionPerformed
        String nim = txtNIM.getText();
        
        if (nim.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Pilih data pada tabel yang ingin dihapus terlebih dahulu!");
            return;
        }
        
        // Memunculkan konfirmasi yes/no sebelum menghapus
        int konfirmasi = JOptionPane.showConfirmDialog(this, "Yakin ingin menghapus data dengan NIM " + nim + "?", "Konfirmasi Hapus", JOptionPane.YES_NO_OPTION);
        
        if (konfirmasi == JOptionPane.YES_OPTION) {
            try {
                String sql = "DELETE FROM mahasiswa WHERE nim='" + nim + "'";
                Statement st = con.createStatement();
                st.executeUpdate(sql);
                
                JOptionPane.showMessageDialog(this, "Data Berhasil Dihapus!");
                load_data();
                clear_form();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Gagal Hapus: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_btnHapusActionPerformed

    private void btnKeluarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnKeluarActionPerformed
        int keluar = JOptionPane.showConfirmDialog(this, "Apakah Anda yakin ingin keluar?", "Keluar Aplikasi", JOptionPane.YES_NO_OPTION);
        if (keluar == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_btnKeluarActionPerformed

    private void cbJurusanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbJurusanActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbJurusanActionPerformed

    private void tableMahasiswaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMahasiswaMouseClicked
        int baris = tableMahasiswa.getSelectedRow();
        
        txtNIM.setText(tableMahasiswa.getValueAt(baris, 0).toString());
        txtNama.setText(tableMahasiswa.getValueAt(baris, 1).toString());
        
        String jk = tableMahasiswa.getValueAt(baris, 2).toString();
        if (jk.equals("Laki-Laki")) {
            rbLaki.setSelected(true);
        } else {
            rbPerempuan.setSelected(true);
        }
        
        cbJurusan.setSelectedItem(tableMahasiswa.getValueAt(baris, 3).toString());
        
        // Kunci NIM agar tidak dapat dimodifikasi saat proses update
        txtNIM.setEditable(false);
    }//GEN-LAST:event_tableMahasiswaMouseClicked


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Jurusan;
    private javax.swing.JButton btnHapus;
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnUbah;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cbJurusan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton rbLaki;
    private javax.swing.JRadioButton rbPerempuan;
    private javax.swing.JTable tableMahasiswa;
    private javax.swing.JTextField txtNIM;
    private javax.swing.JTextField txtNama;
    // End of variables declaration//GEN-END:variables
}

